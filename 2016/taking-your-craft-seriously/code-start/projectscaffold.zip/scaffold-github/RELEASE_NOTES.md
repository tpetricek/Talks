### 1.0 - Unreleased
* More awesome stuff coming
* Added SourceLink for Source Indexing PDB

#### 0.5.1-beta - November 6 2013
* Improved quality of solution-wide README.md files
 
#### 0.5.0-beta - October 29 2013
* Improved quality of solution-wide README.md files

#### 0.0.1-beta - October 24 2013
* Changed name from fsharp-project-scaffold to FSharp.ProjectScaffold
* Initial release
